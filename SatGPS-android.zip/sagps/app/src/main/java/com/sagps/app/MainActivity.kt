package com.sagps.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.drawable.GradientDrawable
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Un satélite reportado por el chip GNSS del teléfono. */
data class Sat(
    val constellation: Int,
    val svid: Int,
    val azimuth: Float,
    val elevation: Float,
    val cn0: Float,
    val usedInFix: Boolean,
) {
    /** Geoestacionario (o GEO) según constelación y número de satélite. */
    val isGeo: Boolean
        get() = when (constellation) {
            GnssStatus.CONSTELLATION_SBAS -> true                       // WAAS, EGNOS, MSAS, GAGAN...
            GnssStatus.CONSTELLATION_BEIDOU -> svid in 1..5 || svid in 59..63 // BeiDou C01-C05, C59-C63 = GEO
            else -> false                                               // GPS, GLONASS, Galileo, QZSS, NavIC: MEO/IGSO
        }

    val name: String
        get() = when (constellation) {
            GnssStatus.CONSTELLATION_GPS -> "GPS"
            GnssStatus.CONSTELLATION_SBAS -> "SBAS"
            GnssStatus.CONSTELLATION_GLONASS -> "GLONASS"
            GnssStatus.CONSTELLATION_QZSS -> "QZSS"
            GnssStatus.CONSTELLATION_BEIDOU -> "BeiDou"
            GnssStatus.CONSTELLATION_GALILEO -> "Galileo"
            GnssStatus.CONSTELLATION_IRNSS -> "NavIC"
            else -> "?"
        } + " #" + svid

    /** Altitud orbital aproximada en km. */
    val altitudeKm: Double
        get() = when (constellation) {
            GnssStatus.CONSTELLATION_GPS -> 20180.0
            GnssStatus.CONSTELLATION_GLONASS -> 19130.0
            GnssStatus.CONSTELLATION_GALILEO -> 23222.0
            GnssStatus.CONSTELLATION_BEIDOU -> if (isGeo) 35786.0 else 21528.0
            else -> 35786.0 // SBAS, QZSS, NavIC (GEO/IGSO)
        }
}

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var summary: TextView
    private lateinit var lm: LocationManager
    private val handler = Handler(Looper.getMainLooper())

    private var me: GeoPoint? = null
    private var sats: List<Sat> = emptyList()
    private var centeredOnce = false

    private val gnssCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            sats = (0 until status.satelliteCount).map { i ->
                Sat(
                    status.getConstellationType(i), status.getSvid(i),
                    status.getAzimuthDegrees(i), status.getElevationDegrees(i),
                    status.getCn0DbHz(i), status.usedInFix(i),
                )
            }.filter { it.cn0 > 0f || it.usedInFix } // solo los que realmente se reciben
            redraw()
        }
    }

    private val locListener = LocationListener { loc: Location ->
        me = GeoPoint(loc.latitude, loc.longitude)
        if (!centeredOnce) {
            centeredOnce = true
            map.controller.setZoom(5.0)
            map.controller.setCenter(me)
        }
        redraw()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        Configuration.getInstance().load(this, getSharedPreferences("osm", Context.MODE_PRIVATE))
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        buildUi()
        ensurePermission()
    }

    private fun buildUi() {
        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            minZoomLevel = 2.0
            maxZoomLevel = 19.0
            controller.setZoom(3.0)
            controller.setCenter(GeoPoint(0.0, -70.0))
        }

        summary = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0xDD202833.toInt())
            setPadding(24, 20, 24, 20)
            textSize = 14f
            text = "Esperando señal GPS…"
        }

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xDD202833.toInt())
            addView(btn("Mi ubicación") { me?.let { map.controller.animateTo(it, 15.0, 800L) } })
            addView(btn("Ver todos") { fitAll() })
        }

        val root = FrameLayout(this)
        root.addView(map, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(summary, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP))
        root.addView(buttons, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun ensurePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) startGps()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) startGps()
        else summary.text = "Se necesita el permiso de ubicación para ver los satélites."
    }

    @SuppressLint("MissingPermission")
    private fun startGps() {
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
        lm.registerGnssStatusCallback(gnssCallback, handler)
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { super.onPause(); map.onPause() }
    override fun onDestroy() {
        super.onDestroy()
        lm.removeUpdates(locListener)
        lm.unregisterGnssStatusCallback(gnssCallback)
    }

    // ---------- Geometría ----------

    /**
     * Punto de la Tierra justo debajo del satélite (sub-satélite), a partir de la
     * posición del usuario y del azimut/elevación que mide el GPS.
     */
    private fun subSatellitePoint(from: GeoPoint, s: Sat): GeoPoint {
        val r = 6371.0
        val e = Math.toRadians(s.elevation.toDouble().coerceIn(0.5, 90.0))
        val central = acos(r * cos(e) / (r + s.altitudeKm)) - e // ángulo central Tierra
        val az = Math.toRadians(s.azimuth.toDouble())
        val lat1 = Math.toRadians(from.latitude)
        val lon1 = Math.toRadians(from.longitude)
        val lat2 = asin(sin(lat1) * cos(central) + cos(lat1) * sin(central) * cos(az))
        val lon2 = lon1 + atan2(
            sin(az) * sin(central) * cos(lat1),
            cos(central) - sin(lat1) * sin(lat2),
        )
        return GeoPoint(Math.toDegrees(lat2), ((Math.toDegrees(lon2) + 540) % 360) - 180)
    }

    // ---------- Dibujo ----------

    private fun redraw() {
        val origin = me
        map.overlays.clear()

        val geo = sats.count { it.isGeo }
        val used = sats.count { it.usedInFix }
        summary.text = "Satélites recibidos: ${sats.size}   (en uso: $used)\n" +
            "Geoestacionarios: $geo    No geoestacionarios: ${sats.size - geo}\n" +
            (if (origin == null) "Buscando tu ubicación…" else "Naranja = geoestacionario · Azul = órbita media")

        if (origin != null) {
            map.overlays.add(dot(origin, "Tú", Color.RED, 34).apply { snippet = "Tu ubicación" })
            for (s in sats) {
                val p = subSatellitePoint(origin, s)
                val color = if (s.isGeo) 0xFFFF8F00.toInt() else 0xFF1E6FD9.toInt()

                map.overlays.add(Polyline(map).apply {
                    setPoints(listOf(origin, p))
                    outlinePaint.color = color
                    outlinePaint.strokeWidth = if (s.usedInFix) 6f else 3f
                    if (!s.usedInFix) outlinePaint.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
                    isGeodesic = true
                })
                map.overlays.add(dot(p, s.name, color, 28).apply {
                    snippet = (if (s.isGeo) "Geoestacionario" else "No geoestacionario") +
                        "\nElevación ${"%.0f".format(s.elevation)}° · Azimut ${"%.0f".format(s.azimuth)}°" +
                        "\nSeñal ${"%.0f".format(s.cn0)} dB-Hz · " + (if (s.usedInFix) "en uso" else "solo visible") +
                        "\nÓrbita ≈ ${"%,.0f".format(s.altitudeKm)} km"
                })
            }
        }
        map.invalidate()
    }

    private fun dot(p: GeoPoint, title: String, color: Int, size: Int) = Marker(map).apply {
        position = p
        this.title = title
        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        icon = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(4, Color.WHITE)
            setSize(size, size)
        }
    }

    private fun fitAll() {
        val pts = buildList {
            me?.let { add(it) }
            me?.let { o -> sats.forEach { add(subSatellitePoint(o, it)) } }
        }
        if (pts.size >= 2) {
            map.zoomToBoundingBox(BoundingBox.fromGeoPointsSafe(pts).increaseByScale(1.3f), true, 80)
        }
    }
}
